function [eMin, eMax] = costate_catalog_extremes(cat_, filt, doPlot, metric)
%% Purpose:
%
%   Finds the EXTREME transfers in the multi-orbit costate CATALOG -- by
%   Delta-V (default) or by flight time -- and reports each extreme's full
%   coordinates: which sheet (DRO period, petal count), which phase pair
%   (nondimensional time AND days), which thrust rung, plus flight time,
%   Delta-V and propellant. Optionally flies both and plots them side by
%   side, each above its own sheet's orbits.
%
%   The catalog is COMPACT, so Delta-V is derived on the fly (exact for
%   these all-burn minimum-time solutions):
%       mf = 1 - Tmax_nd*tf_nd/c_nd,   dV = c_nd*ln(1/mf)*lStar/tStar.
%
%   RESTRICT THE SEARCH with the filter -- comparisons are most meaningful
%   with thrust held fixed (at one thrust, min time and min Delta-V are the
%   SAME transfer; they only separate across thrust levels), and often with
%   one sheet held fixed (isolating pure phasing effects).
%
%% Inputs:
%
%  cat_                     struct                  A compact costate catalog
%                                                   (any family: dro_tulip,
%                                                   halo_tulip, ...)
%
%  filt                     struct                  Optional restrictions,
%                                                   any subset of:
%                                                   .tauDRO  DRO period (ND)
%                                                   .Np      petal count
%                                                   .thrustN rung (N)
%                                                   .status  vector of
%                                                   optimality-status codes
%                                                   (primaries AND
%                                                   alternatives)
%                                                   .includeAlternatives
%                                                   [false] also search
%                                                   cat_.alternatives
%                                                   [] or omitted = search
%                                                   the whole catalog
%
%  doPlot                   logical                 true: fly both extremes
%                                                   and draw side by side
%                                                   (default false)
%
%  metric                   char                    'deltaV' (default) or
%                                                   'time'
%
%% Outputs:
%
%  eMin                     struct                  The extreme entries:
%  eMax                                             .tauDRO .Np .thrustN
%                                                   .dep_frac/_nd/_days
%                                                   .arr_frac/_nd/_days
%                                                   .tf_nd/.tf_days
%                                                   .deltaV_kms
%                                                   .propellant_kg
%                                                   .z8 [8x1] (tfMin-ready)
%                                                   .kind 'primary' |
%                                                   'alternative'
%                                                   .status (NaN: no layer)
%                                                   .statusName .reason
%                                                   .junctions .altIndex
%
%% Revision History:
%  M. Casey                                                   (c) 08/06/2026
%  M. Casey  alternatives and status filters, defaults unchanged
%                                                              (c) 10/13/2026
%  M. Casey  self-demo uses the catalog's rung nearest 5 N (a
%            one-rung 70 mN catalog has no 5 N entries)   (c) 10/13/2026
%  Copyright Coorbital Inc.
%% ------------------------ Begin Code Sequence ---------------------------

if nargin == 0
   %Demo: pure phasing effect -- the mid sheet, one thrust, with the plot.
   %Runs on whichever compact catalog sits in the current folder:
     F = dir('costate_catalog_*.mat');
     assert(~isempty(F), ...
            'demo: no costate_catalog_*.mat in the current folder');
       L = load(F(1).name);
      fn = fieldnames(L);
    cat_ = L.(fn{1});
   fprintf('demo catalog: %s\n', F(1).name);
      sh = cat_.sheets(ceil(numel(cat_.sheets)/2));
   [~,kDemo] = min(abs(cat_.rungs_N - 5));  tDemo = cat_.rungs_N(kDemo);  % 5 N when stored
   if isnan(sh.Np)
       fl = struct('tauDRO',sh.tauDRO,'tauArr',sh.tau_arr,'thrustN',tDemo);
   else
       fl = struct('tauDRO',sh.tauDRO,'Np',sh.Np,'thrustN',tDemo);
   end
[eMin,eMax] = costate_catalog_extremes(cat_, fl, true);
     return;
end
if ~exist('filt','var') || isempty(filt), filt = struct(); end
if ~exist('doPlot','var'), doPlot = false; end
if ~exist('metric','var'), metric = 'deltaV'; end
assert(any(strncmpi(metric, {'deltaV','time'}, 1)), ...
       'metric must be ''deltaV'' or ''time'', got ''%s''', metric);

   tStar = cat_.constants.tStar_s;
   lStar = cat_.constants.lStar_km;
     cnd = cat_.thruster.c_nd;
    m0kg = cat_.thruster.m0_kg;
   d2day = tStar/86400;
useAlt = isfield(filt,'includeAlternatives') && ~isempty(filt.includeAlternatives) && filt.includeAlternatives;
useSt  = isfield(filt,'status') && ~isempty(filt.status);
     ndT = @(TN) (TN/m0kg)*tStar^2/(lStar*1000);

%% Walk every stored entry, apply the filter, rank by the metric:
    best = [];  worst = [];
   vBest = inf;  vWorst = -inf;
for ks = 1:numel(cat_.sheets)
    sh = cat_.sheets(ks);
    if isfield(filt,'tauDRO') && abs(sh.tauDRO - filt.tauDRO) > 1e-9, continue, end
    if isfield(filt,'Np')
        assert(~isnan(sh.Np), 'costate_catalog_extremes:NpFilter', ...
            'this catalog''s arrival family is not tulip: filter by .tauArr, not .Np');
        if sh.Np ~= filt.Np, continue, end
    end
    if isfield(filt,'tauArr') && isfield(sh,'tau_arr') && ...
       abs(sh.tau_arr - filt.tauArr) > 1e-9,                          continue, end
    for kr = 1:numel(cat_.rungs_N)
        TN = cat_.rungs_N(kr);
        if isfield(filt,'thrustN') && abs(TN - filt.thrustN) > 1e-9, continue, end
        for iD = 1:numel(sh.sD_frac)
            for iA = 1:numel(sh.sA_frac)
                if ~sh.has_solution(iD,iA,kr), continue, end
                if useSt
                    if ~isfield(sh,'status') || ~ismember(double(sh.status(iD,iA,kr)), filt.status), continue, end
                end
                tf = sh.tf_nd(iD,iA,kr);
                mf = 1 - ndT(TN)*tf/cnd;
                if ~(mf > 0 && mf <= 1), continue, end   % corrupt entry
                dV = cnd*log(1/mf)*lStar/tStar;
                if strncmpi(metric,'t',1), v = tf; else, v = dV; end
                if v < vBest
                    vBest = v;  best  = pack(sh, iD, iA, TN, tf, dV, mf, m0kg, d2day, ...
                                             sh.z8(:,sh.entry_index(iD,iA,kr)));
                    best = addStatus(best, sh, iD, iA, kr);
                end
                if v > vWorst
                    vWorst = v;  worst = pack(sh, iD, iA, TN, tf, dV, mf, m0kg, d2day, ...
                                              sh.z8(:,sh.entry_index(iD,iA,kr)));
                    worst = addStatus(worst, sh, iD, iA, kr);
                end
            end
        end
    end
    %% Alternatives of this sheet (same filter, same ranking):
    if useAlt && isfield(cat_,'alternatives') && ~isempty(cat_.alternatives)
        AL = cat_.alternatives;
        for ka = find([AL.sheet] == ks)
            if numel(cat_.rungs_N) ~= 1, continue, end   % alternatives are stored at the one library rung
            TN = cat_.rungs_N(1);
            if isfield(filt,'thrustN') && abs(TN - filt.thrustN) > 1e-9, continue, end
            if useSt && ~ismember(double(AL(ka).status), filt.status), continue, end
            tf = AL(ka).tf_nd;
            mf = 1 - ndT(TN)*tf/cnd;
            if ~(mf > 0 && mf <= 1), continue, end
            dV = cnd*log(1/mf)*lStar/tStar;
            if strncmpi(metric,'t',1), v = tf; else, v = dV; end
            if v < vBest
                vBest = v;
                best = packAlt(sh, AL(ka), ka, TN, tf, dV, mf, m0kg, d2day);
            end
            if v > vWorst
                vWorst = v;
                worst = packAlt(sh, AL(ka), ka, TN, tf, dV, mf, m0kg, d2day);
            end
        end
    end
end
assert(~isempty(best), 'no catalog entries match the filter');
eMin = best;  eMax = worst;

%% Report:
if strncmpi(metric,'t',1), mName = 'flight time'; else, mName = 'Delta-V'; end
fprintf('\n%s extremes%s:\n', mName, filtstr(filt));
report('MINIMUM', eMin);
report('MAXIMUM', eMax);

if ~doPlot, return, end

%% Side-by-side plot, each extreme above its own sheet's orbits:
      mu = cat_.constants.muStar;
figure('Color','w','Position',[60 60 1200 560]);
ttl = {sprintf('MINIMUM %s', mName), sprintf('MAXIMUM %s', mName)};
for kp = 1:2
    if kp == 1, e = eMin; else, e = eMax; end
    [tD, rvD] = get_family_orbit(e.dep_family, e.dep_params);
    [tT, rvT] = get_family_orbit(e.arr_family, e.arr_params);
    rv0 = interp1(tD, rvD, e.dep_frac*tD(end), 'spline');
    rvf = interp1(tT, rvT, e.arr_frac*tT(end), 'spline');
    [~, y] = pumpkyn.cr3bp.tfMinProp(e.z8(8), [rv0(1:6)'; 1; e.z8(1:7)], ...
                 ndT(e.thrustN), cnd, mu);
    subplot(1,2,kp);
    plot3(y(:,1), y(:,2), y(:,3), 'b', 'LineWidth', 1.2); hold on;
    plot3(rvD(:,1), rvD(:,2), rvD(:,3), 'k--');
    plot3(rvT(:,1), rvT(:,2), rvT(:,3), 'r--');
    plot3(rv0(1), rv0(2), rv0(3), '.g', 'MarkerSize', 18);
    plot3(rvf(1), rvf(2), rvf(3), '.r', 'MarkerSize', 18);
    axis equal; grid on; view(-35, 25);
    xlabel('x [ND]'); ylabel('y [ND]'); zlabel('z [ND]');
    title({ttl{kp}, ...
        sprintf('%s \\tau=%.2f, %s, %.2f N', upper(e.dep_family), ...
                e.tauDRO, e.arrLab, e.thrustN), ...
        sprintf('\\DeltaV %.4f km/s,  t_f %.3f d,  %.2f kg prop', ...
                e.deltaV_kms, e.tf_days, e.propellant_kg), ...
        sprintf('depart %.3f d, arrive %.3f d', e.dep_days, e.arr_days)});
    if kp == 1
        legend('transfer','departure','tulip','depart','arrive','Location','best');
    end
end
rotate3d on
end

% ------------------------------------------------------------------------
function e = pack(sh, iD, iA, TN, tf, dV, mf, m0kg, d2day, z8)
% PACK  Assemble one extreme's report struct.
% INPUTS: sheet struct; indices; thrust; tf (ND); dV (km/s); final mass
%         fraction; m0 (kg); ND->days factor; z8.  OUTPUTS: e struct.
Pd = sh.tauDRO;  Pa = sh.period_tulip_nd;
% Departure reconstruction recipe: multi-family catalogs carry it per sheet;
% the original DRO catalog predates the fields, so fall back to its rule
if isfield(sh, 'dep_family')
    df = sh.dep_family;  dp = sh.dep_params;
else
    df = 'dro';  dp = struct('tau', sh.tauDRO);
end
% Arrival recipe: v2 catalogs carry it; v1 catalogs are tulip-arrival
if isfield(sh, 'arr_family')
    af = sh.arr_family;  ap = sh.arr_params;
else
    af = 'tulip';  ap = struct('Np', sh.Np, 'pm', -1);
end
if strcmpi(af, 'tulip')
    aLab = sprintf('Np=%d', sh.Np);
else
    aLab = sprintf('arr \\tau=%.2f', ap.tau);
end
e = struct('tauDRO',sh.tauDRO, 'dep_family',df, 'dep_params',dp, ...
    'arr_family',af, 'arr_params',ap, 'arrLab',aLab, ...
    'Np',sh.Np, 'thrustN',TN, ...
    'dep_frac',sh.sD_frac(iD), 'dep_nd',sh.sD_frac(iD)*Pd, ...
    'dep_days',sh.sD_frac(iD)*Pd*d2day, ...
    'arr_frac',sh.sA_frac(iA), 'arr_nd',sh.sA_frac(iA)*Pa, ...
    'arr_days',sh.sA_frac(iA)*Pa*d2day, ...
    'tf_nd',tf, 'tf_days',tf*d2day, 'deltaV_kms',dV, ...
    'propellant_kg',(1-mf)*m0kg, 'z8',z8, ...
    'kind','primary', 'status',NaN, 'statusName','', 'reason','', ...
    'junctions',[], 'altIndex',0);
end

% ------------------------------------------------------------------------
function e = addStatus(e, sh, iD, iA, kr)
% ADDSTATUS  Fill a primary extreme's status fields when the sheet has the
% layer.  INPUTS: e extreme; sh sheet; indices.  OUTPUTS: e.
ie = sh.entry_index(iD,iA,kr);
if isfield(sh,'status')
    e.status = double(sh.status(iD,iA,kr));
    e.statusName = statusName(e.status);
end
if isfield(sh,'status_reason') && ~isempty(sh.status_reason), e.reason = sh.status_reason{ie}; end
if isfield(sh,'junctions') && ~isempty(sh.junctions), e.junctions = sh.junctions{ie}; end
end

% ------------------------------------------------------------------------
function e = packAlt(sh, a, ka, TN, tf, dV, mf, m0kg, d2day)
% PACKALT  Assemble an alternative's extreme struct (same fields as a
% primary).  INPUTS: sheet; alternative row; its index; thrust; tf (ND);
% dV (km/s); final mass fraction; m0 (kg); ND->days factor.  OUTPUTS: e.
[~, iD] = min(abs(sh.sD_frac - a.sD));
[~, iA] = min(abs(sh.sA_frac - a.sA));
e = pack(sh, iD, iA, TN, tf, dV, mf, m0kg, d2day, a.z8);
e.dep_frac = a.sD;  e.dep_nd = a.sD*sh.tauDRO;  e.dep_days = e.dep_nd*d2day;
e.arr_frac = a.sA;  e.arr_nd = a.sA*sh.period_tulip_nd;  e.arr_days = e.arr_nd*d2day;
e.kind = 'alternative';  e.status = double(a.status);
e.statusName = statusName(e.status);  e.reason = a.status_reason;
e.junctions = a.junctions;  e.altIndex = ka;
end

% ------------------------------------------------------------------------
function n = statusName(code)
% STATUSNAME  Name of a status code via status_key.  INPUTS: code.
% OUTPUTS: n [char].
K = status_key();
n = K.names{K.codes == code};
end

% ------------------------------------------------------------------------
function report(tag, e)
% REPORT  Print one extreme in both unit systems.
% INPUTS: tag [char]; e extreme struct.  OUTPUTS: none.
fprintf('  %s  dV = %.4f km/s,  t_f = %.5f ND = %.3f d   [%s tau=%.2f, %s, %.2f N, %.2f kg]\n', ...
        tag, e.deltaV_kms, e.tf_nd, e.tf_days, upper(e.dep_family), ...
        e.tauDRO, strrep(e.arrLab,'\tau','tau'), e.thrustN, ...
        e.propellant_kg);
if strcmp(e.kind,'alternative') || ~isnan(e.status)
    fprintf('      status: %s -- %s%s\n', e.statusName, e.reason, ...
            ternary(strcmp(e.kind,'alternative'), sprintf('  [alternative #%d]', e.altIndex), ''));
end
fprintf('      departure phase: %.6f ND = %.4f days  (fraction %.4f)\n', ...
        e.dep_nd, e.dep_days, e.dep_frac);
fprintf('      arrival   phase: %.6f ND = %.4f days  (fraction %.4f)\n', ...
        e.arr_nd, e.arr_days, e.arr_frac);
end

% ------------------------------------------------------------------------
function s = filtstr(filt)
% FILTSTR  Human-readable filter description.  INPUTS: filt.  OUTPUTS: s.
s = '';
if isfield(filt,'tauDRO'), s = [s sprintf(' tau=%.2f', filt.tauDRO)]; end
if isfield(filt,'Np'),     s = [s sprintf(' Np=%d', filt.Np)]; end
if isfield(filt,'tauArr'), s = [s sprintf(' arr tau=%.2f', filt.tauArr)]; end
if isfield(filt,'thrustN'),s = [s sprintf(' %.2g N', filt.thrustN)]; end
if isfield(filt,'status') && ~isempty(filt.status), s = [s sprintf(' status=%s', mat2str(filt.status))]; end
if isfield(filt,'includeAlternatives') && ~isempty(filt.includeAlternatives) && filt.includeAlternatives
    s = [s ' +alternatives'];
end
if isempty(s), s = ' over the WHOLE catalog';
else, s = [' (restricted to' s ')'];
end
end

% ------------------------------------------------------------------------
function r = ternary(c, a, b)
% TERNARY  a if c else b.  INPUTS: c logical; a,b values.  OUTPUTS: r.
if c, r = a; else, r = b; end
end
